﻿using Newtonsoft.Json.Linq;
using System.Net.Http;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private async void PrzyciskPorady_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var losowaPorada = await Porada.LosujPorade();
                //Na podstawie wyniku z Api wypisujemy zawartość porady
                Poradatxt.Text = $"\"{losowaPorada}\"";
            }
            catch (Exception ex)
            {
                //Obsluga wyjatkow
                Poradatxt.Text = "Blad pobierania cytatu";


            }
        }
    }
}