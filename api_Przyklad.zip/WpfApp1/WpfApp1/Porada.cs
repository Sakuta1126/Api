﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public static class Porada
    {
        public static async Task<string> LosujPorade()
        {
            string apiUrl = "https://api.adviceslip.com/advice";
            using (HttpClient klient = new HttpClient()) // Tworzymy klienta do wysylania zapytan do serwera
            {
                HttpResponseMessage odpowiedz = await klient.GetAsync(apiUrl); // Wysyla zadanie GET do naszego API
                odpowiedz.EnsureSuccessStatusCode(); //Sprawdzamy czy została nam udzielona odpowiedź na żadanie
                string odp = await odpowiedz.Content.ReadAsStringAsync(); //Odczytuje odpowiedz jako tekst w formacie Json
                //Parsujemy Jsona i wyciagamy wartosc porady
                var json = JObject.Parse(odp);
                string porada = json["slip"]["advice"].ToString();

                return porada; // Zwracamy wynik jako lancuch znakow;
            }
        }
    }
}
